import 'package:flutter/material.dart';

class MessageFragment extends StatelessWidget {
  final TextEditingController _textEditingController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Secret Message App'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            const Text(
              'Enter Your Message',
              style: TextStyle(fontSize: 24),
            ),
            const SizedBox(height: 23),
            TextField(
              controller: _textEditingController,
              decoration: const InputDecoration(
                labelText: 'Message',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 23),
            ElevatedButton(
              onPressed: () {
                final message = _textEditingController.text;
                Navigator.pushNamed(context, '/encrypt', arguments: message);
              },
              child: const Text('Next'),
            ),
          ],
        ),
      ),
    );
  }
}
