import 'package:flutter/material.dart';

class EncryptFragment extends StatelessWidget {
  final String message;

  const EncryptFragment({required this.message});

  @override
  Widget build(BuildContext context) {
    final encryptedMessage = encrypt(message);

    return Scaffold(
      appBar: AppBar(
        title:const Text('Secret Message App'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'Encrypted Message',
              style: TextStyle(fontSize: 24),
            ),
            const SizedBox(height: 16,),
            Text(
              encryptedMessage,
              style: const TextStyle(fontSize: 20),
            ),
          ],
        ),
      ),
    );
  }
}

String encrypt(String message) {
    // Implement your blur logic here
    String encryptedMessage = '';

    for (int i = 0; i < message.length; i++) {
      if (message[i] == ' ') {
        encryptedMessage += ' '; // Keep spaces as is
      } else {
        encryptedMessage += '*'; // Replace non-space characters with *
      }
    }

    return encryptedMessage;
}