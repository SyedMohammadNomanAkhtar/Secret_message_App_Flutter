import 'package:flutter/material.dart';
import 'Welcome_Fragment.dart';
import 'Message_Fragment.dart';
import 'Encrypt_Fragment.dart';

void main() {
  runApp(SecretMessageApp());
}

class SecretMessageApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Secret Message App',
      initialRoute: '/',
      routes: {
        '/': (context) => WelcomeFragment(),
        '/message': (context) => MessageFragment(),
        '/encrypt': (context) => EncryptFragment(message: ModalRoute.of(context)!.settings.arguments as String),
      },
    );
  }
}
