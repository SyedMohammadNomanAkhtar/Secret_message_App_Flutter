package com.example.secret_message_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
